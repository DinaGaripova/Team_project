<?
	if(isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	else header("Location: insex.php");
	require_once 'vendor/connect.php';
	
	function translit_sef($value)
	{
		$converter = array(
			'а' => 'a',    'б' => 'b',    'в' => 'v',    'г' => 'g',    'д' => 'd',
			'е' => 'e',    'ё' => 'e',    'ж' => 'zh',   'з' => 'z',    'и' => 'i',
			'й' => 'y',    'к' => 'k',    'л' => 'l',    'м' => 'm',    'н' => 'n',
			'о' => 'o',    'п' => 'p',    'р' => 'r',    'с' => 's',    'т' => 't',
			'у' => 'u',    'ф' => 'f',    'х' => 'h',    'ц' => 'c',    'ч' => 'ch',
			'ш' => 'sh',   'щ' => 'sch',  'ь' => '',     'ы' => 'y',    'ъ' => '',
			'э' => 'e',    'ю' => 'yu',   'я' => 'ya',
		);
	 
		$value = mb_strtolower($value);
		$value = strtr($value, $converter);
		$value = mb_ereg_replace('[^-0-9a-z]', '-', $value);
		$value = mb_ereg_replace('[-]+', '-', $value);
		$value = trim($value, '-');	
	 
		return $value;
	}
	
	$query = "SELECT * FROM users WHERE token = '". $_SESSION['token']."'";
	$result = mysqli_query($link, $query);
	$profile = mysqli_fetch_assoc($result);
	
	if (!empty($_POST['name']) || !empty($_POST['surname']) || !empty($_POST['email']) || $_FILES['photo']['type'] == 'image/jpeg' || $_FILES['photo']['type'] == 'image/png')
	{
		$query = "UPDATE users SET ";
		if (!empty($_POST['name'])) 		$query .= "name = '".$_POST['name']."'";
		if (!empty($_POST['surname'])) 		$query .= ", family = '".$_POST['surname']."'";
		if (!empty($_POST['email'])) 		$query .= ", email = '".$_POST['email']."'";
		if ($_FILES['photo']['type'] == 'image/jpeg'||$_FILES['photo']['type'] == 'image/png')
		{
			$uploaddir = 'images/profiles/';
			$uploadfile = translit_sef($profile["family"]." ".$profile["name"]) . ".jpg";
			$query .= ", photo = '$uploadfile'";
			$result = mysqli_query($link,$query);
			$uploadfile = $uploaddir . $uploadfile;
			move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile);
		}
		$query .= " WHERE token = '".$_SESSION["token"]."'"; 
		$query = str_replace("SET ,", "SET", $query);
		$result = mysqli_query($link,$query);
		header ("Location: profile.php");
	}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="style CSS/style.css">
	<link rel="shortcut icon" href="images/icons/favicon.ico" type="image/x-icon">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
	<meta charset="utf-8">
	<title>NatiAir</title>
</head>
<style>
.img_1
{
	height: 60px;
	margin: 10px;
}
.img_2
{
	height: 40px;
	margin: 13px;
}
.img_3
{
	height: 1200px;
}
.img_4
{
	height: 30px;
	margin: 13px;
}
</style>
<body>
	<div class="header_line">
		<div class="header_content_container">
			<div class="header_content">
				<div class="logo">
					<a href="index.php"><img src="images/full logo исходник.png" class="img_1" alt=""></a>
				</div>
				<div class="round_blocks headerButton">
					<a href="about_us.php">about us</a>
				</div>
				<div class="round_blocks headerButton">
					<a href="all_flights.php">all flights</a>
				</div>
				<?if(isset($_COOKIE[session_name()])){?>
				<div class="round_blocks headerButton">
					<a href="my_tickets.php">my tickets</a>
				</div>
				<?}?>
				<div class="login">
				<?if(isset($_COOKIE[session_name()])){?>
					<a href="profile.php"><?= $profile['login']?></a>
					<a href="vendor/logout.php">Exit</a>
				<?}
				else{?>
					<a href="auth.php">login</a>
				<?}?>
				</div>
			</div>
		</div>
	</div>
    <div class="background">
		<div class="content_blok">
			<div class="container rounded bg-white mt-5 mb-5">
				<div class="row">
					<div class="col-md-4 mx-auto border-right">
						<div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" src=<?if (empty($profile['photo'])){?>"https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"<?}else{?>images/profiles/<?=$profile['photo']?><?}?>><span class="font-weight-bold"><?= $profile['name']?></span><span class="text-black-50"><?= $profile['email']?></span><span> </span></div>
					</div>
					<?if($_GET['changeMode']==true){?>
					<div class="col-md-9 mx-auto border-right">
						<div class="p-3 py-5">
							<div class="d-flex justify-content-between align-items-center mb-3">
								<h4 class="text-right">Profile Settings</h4>
							</div>
							<form enctype="multipart/form-data" method="POST" action="">
								<div class="mb-3">
									<label class="form-label">Photo</label>
									<input type="file" class="form-control" name="photo" accept="image/jpeg,image/png">
								</div>
								<div class="row mt-2">
									<div class="col-md-6"><label class="labels">Name</label><input type="text" class="form-control" placeholder="first name" name="name" pattern="[A-ZА-Я]{1}[a-zа-я]{1,}" value=""></div>
									<div class="col-md-6"><label class="labels">Surname</label><input type="text" class="form-control" value="" placeholder="surname" pattern="[A-ZА-Я]{1}[a-zа-я]{1,}" name="surname"></div>
								</div>
								<div class="row mt-3">
									<div class="col-md-12"><label class="labels">Email</label><input type="email" class="form-control" placeholder="enter email" name="email" value=""></div>
								</div>
								<div class="row mt-2">
									<div class="col-md-4"><button class="btn btn-primary profile-button" onClick="location.href='profile.php'" type="button">Return to view</button></div>
									<div class="col-md-4 offset-md-4"><button class="btn btn-primary profile-button" type="submit">Save Profile</button></div>
								</div>
							</form>
						</div>
					</div>
					<?}
					else{?>
					<div class="col-md-9 mx-auto border-right">
						<div class="p-3 py-5">
							<div class="d-flex justify-content-between align-items-center mb-3">
								<h4 class="text-right">Profile</h4>
							</div>
							<div class="row mt-3">
								<div class="col-md-6"><label class="labels">Name</label></div>
								<div class="col-sm-6">
									<p class="text-muted mb-0"><?= $profile['name']?></p>
								</div>
							</div>
							<div class="row mt-3">
								<div class="col-md-6"><label class="labels">Surname</label></div>
								<div class="col-sm-6">
									<p class="text-muted mb-0"><?= $profile['family']?></p>
								</div>
							</div>
							<div class="row mt-3">
								<div class="col-md-6"><label class="labels">Email</label></div>
								<div class="col-sm-6">
									<p class="text-muted mb-0"><?= $profile['email']?></p>
								</div>
							</div>
							<div class="mt-5 text-center"><button class="btn btn-primary profile-button" onClick="location.href='?changeMode=true'" type="button">Change Profile</button></div>
						</div>
					</div>
					<?}?>
				</div>
			</div>
		</div>
    </div>
    <div class="all">
      <div class="basement">
        <div class="tr">
            © 2022–2022, Natiair — cheap air tickets.
        </div>
        <div class="tu">
					<div class="ti">
						<img src="images/vk.png" class="img_4" alt="">
					</div>
					<div class="ti">
						<img src="images/youtube.png" class="img_4" alt="">
					</div>
					<div class="ti">
						<img src="images/telegram.png" class="img_4" alt="">
					</div>
				</div>
			</div>
		</div>
	</body>
</html>