<head>
	<meta charset="UTF-8">
	<title>NatiAir</title>
	<style>
		body{
			font-family: Montserrat, sans-serif;
			display:flex;
			justify-content:center;
			align-items:center;
		}
		.background
		{
		  display: flex;
		  justify-content: center;
		  background-image: linear-gradient(rgba(255, 255, 255, 0.7),rgba(255, 255, 255, 0.7)), url("images/фон первого блока.jpg");
		  background-size: cover;
		  background-repeat: no-repeat;
		}
		form{
			background-color: #4dd2ff;
			border-radius: 10px;
			display:flex;
			flex-direction:column;
			width:400px;
			padding: 50px 50px;
		}
		input{
			margin: 10px 0;
			padding: 10px;
			border: unset;
			border-bottom: 2px solid #e3e3e3;
			outline: none;
			border-radius: 10px;
		}
		button{
			padding: 10px;
			background: #9ee7ff;
			border:unset;
			cursor:pointer;
			border-radius: 10px;
		}
		a{
			color: #005872;
			font-weight:bold;
			text-decoration: none;
		}
		p{
			margin: 10px 0;
		} 
		.msg{
			border:2px solid #ffa908;
			border-radius: 3px;
			padding:10px;
			text-align: center;
			font-weight:bold;
		}
	</style>
</head>
<body class="background">
	<form action="vendor/signup.php" method="post">
		<p align=center><a href="index.php" ><img src="images/full logo исходник.png" class="img_1" alt=""></a></p>
		<label>Surname</label>
		<input type="text" name="family" pattern="[A-ZА-Я]{1}[a-zа-я]{1,}" placeholder="Enter your surname">
		<label>Name</label>
		<input type="text" name="name" pattern="[A-ZА-Я]{1}[a-zа-я]{1,}" placeholder="Enter your name">
		<label>Login</label>
		<input type="text" name="login" pattern="[A-Za-z\.]{4,}" placeholder="Enter your login">
		<label>Email</label>
		<input type="email" name="email" placeholder="Enter your email">
		<label>Password</label>
		<input type="password" name="pass" pattern="[A-Za-z0-9]{4,}" placeholder="Enter your password">
		<button type="submit">Register</button>
		<p>
			Do you already have an account? - <a href="auth.php">Authorization</a>
		</p>
		<?php 
			if(isset($_COOKIE['message']))
			{
				echo '<p class="msg">' . $_COOKIE['message'] . '</p>';
			}
			setcookie('message', '', time()-100,"/");
		?>
	</form>
</body>