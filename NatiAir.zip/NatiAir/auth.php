
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon" href="images/icons/favicon.ico" type="image/x-icon">
	<title>NatiAir</title>
	<style>
		body{
			font-family: Montserrat, sans-serif;
			display:flex;
			justify-content:center;
			align-items:center;
		}
		.background
		{
		  display: flex;
		  justify-content: center;
		  background-image: linear-gradient(rgba(255, 255, 255, 0.7),rgba(255, 255, 255, 0.7)), url("images/фон первого блока.jpg");
		  background-size: cover;
		  background-repeat: no-repeat;
		}
		form{
			background-color: #4dd2ff;
			border-radius: 10px;
			display:flex;
			flex-direction:column;
			width:400px;
			padding: 50px 50px;
		}
		input{
			margin: 10px 0;
			padding: 10px;
			border: unset;
			border-bottom: 2px solid #e3e3e3;
			outline: none;
			border-radius: 10px;
		}
		button{
			padding: 10px;
			background: #9ee7ff;
			border:unset;
			cursor:pointer;
			border-radius: 10px;
		}
		a{
			color: #005872;
			font-weight:bold;
			text-decoration: none;
		}
		p{
			margin: 10px 0;
		} 
		.msg{
			border:2px solid #ffa908;
			border-radius: 3px;
			padding:10px;
			text-align: center;
			font-weight:bold;
		}
	</style>
</head>
<body class="background">
	<form action="vendor/signin.php" method="post">
		
		<p align=center><a href="index.php" ><img src="images/full logo исходник.png" class="img_1" alt=""></a></p>

		<label>Login</label>
		<input type="text" name="login" pattern="[A-Za-z\.]{4,}" placeholder="Enter your login">
		<label>Password</label>
		<input type="password" name="pass" pattern="[A-Za-z0-9]{4,}" placeholder="Enter your password">
		<button type="submit">Log in</button>
		<p>
			Don't you have an account? - <a href="register.php">Registration</a>
		</p>
		<?php 
			if($_COOKIE['message'])
			{
				echo '<p class="msg">' . $_COOKIE['message'] . '</p>';
			}
			setcookie('message', '', time()-100,"/");
		?>
	</form>
</body>