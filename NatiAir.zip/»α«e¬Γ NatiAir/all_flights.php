<?
	if(isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	require_once 'vendor/connect.php';
	
	$query = "SELECT * FROM users WHERE token = '". $_SESSION['token']."'";
	$result = mysqli_query($link, $query);
	$profile = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
	<link rel="stylesheet" href="style CSS/style.css">
    <link rel="stylesheet" href="style CSS/style-3.css">
    <link rel="shortcut icon" href="images/icons/favicon.ico" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <meta charset="utf-8">
    <title>NatiAir</title>
  </head>
  <style>
  .img_1
  {
    height: 60px;
    margin: 10px;
  }
  .img_2
  {
    height: 40px;
    margin: 13px;
  }
  .img_3
  {
    height: 1200px;
  }
  .img_4
  {
    height: 30px;
    margin: 13px;
  }
  </style>
  <body>
    <div class="header_line">
      <div class="header_content_container">
        <div class="header_content">
          <div class="logo">
            <a href="index.php"><img src="images/full logo исходник.png" class="img_1" alt=""></a>
          </div>
          <div class="round_blocks headerButton">
				<a href="about_us.php">about us</a>
            </div>
			<div class="round_blocks headerButton">
				<a href="all.php">all flights</a>
            </div>
          <div class="login">
			<?if(isset($_COOKIE[session_name()])){?>
				<a href="#"><?= $profile['name']?></a>
				<a href="vendor/logout.php">Exit</a>
			<?}
			else{?>
				<a href="auth.php">login</a>
			<?}?>
		  </div>
		  </div>
        </div>
      </div>
	</div>
	<br></br>
	<?
		$sql = "SELECT * FROM `air`";
			if($result = $link->query($sql))
			{
				echo "<table><tr><th>fly out of</th><th>fly to</th><th>date</th><th>number</th><th>price</th></tr>";
				foreach($result as $row){
					echo "<tr>";
						echo "<td>" . $row["fly out of"] . "</td>";
						echo "<td>" . $row["fly to"] . "</td>";
						echo "<td>" . $row["date"] . "</td>";
						echo "<td>" . $row["number"] . "</td>";
						echo "<td>" . $row["cell"] . "</td>";
					echo "</tr>";
				}
				echo "</table>";
				$result->free();
			}
	?>
	<div class="all">
      <div class="basement">
        <div class="tr">
            © 2022–2022, Natiair — cheap air tickets.
        </div>
        <div class="tu">
          <div class="ti">
            <img src="images/vk.png" class="img_4" alt="">
          </div>
          <div class="ti">
            <img src="images/youtube.png" class="img_4" alt="">
          </div>
          <div class="ti">
            <img src="images/telegram.png" class="img_4" alt="">
          </div>
        </div>
      </div>
    </div>
	</body>
</html>