<?
	if(isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	require_once 'vendor/connect.php';
	
	$query = "SELECT * FROM users WHERE token = '". $_SESSION['token']."'";
	$result = mysqli_query($link, $query);
	$profile = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="style CSS1/style-2.css">
	<link rel="stylesheet" href="style CSS/style.css">
    <link rel="shortcut icon" href="images/icons/favicon.ico" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <meta charset="utf-8">
    <title>NatiAir</title>
  </head>
  <style>
  .img_1
  {
    height: 60px;
    margin: 10px;
  }
  .img_2
  {
    height: 160px;
    margin: 20px;
    border-radius: 100%;
  }
  </style>
  <body>
    <div class="header_line">
      <div class="header_content_container">
        <div class="header_content">
          <div class="logo">
            <a href="index.php"><img src="images1/full logo исходник.png" class="img_1" alt=""></a>
          </div>
          <div class="round_blocks headerButton">
				<a href="index-2.php">about us</a>
            </div>
			<div class="round_blocks headerButton">
				<a href="all_flights.php">all flights</a>
            </div>
          <div class="login">
			<?if(isset($_COOKIE[session_name()])){?>
				<a href="#"><?= $profile['name']?></a>
				<a href="vendor/logout.php">Exit</a>
			<?}
			else{?>
				<a href="auth.php">login</a>
			<?}?>
		  </div>
		  </div>
        </div>
      </div>
	</div>
    <div class="background">
      <div class="blur">

      </div>
      <div class="bloks">
        <div class="rty">
          <div class="photo">
            <img src="images1/photo/sasha.jpg" class="img_2"alt="">
          </div>
          <div class="try">
            <div class="title">
              Alexander Churakov
            </div>
            <div class="cont">
              Александр занимался дизайном блок-схем проекта, черновыми набросками и cоставил план-ориентацию для развития идеи создания данного сайта.
            </div>
          </div>
        </div>
        <div class="rty">
          <div class="photo">
            <img src="images1/photo/dina.jpg" class="img_2"alt="">
          </div>
          <div class="try">
            <div class="title">
              Dina Garipova
            </div>
            <div class="cont">
              Как сообщила Дина, это её настоящее фото))) В данном проекте она занималась базами данных и разработкой на серверной стороне.
          </div>
        </div>
      </div>
      <div class="rty">
        <div class="photo">
          <img src="images1/photo/kostya.jpg" class="img_2"alt="">
        </div>
        <div class="try">
          <div class="title">
            Konstantin Petrov
          </div>
          <div class="cont">
            Основная работа Константина заключалась в вёрстве сайта и подготовке визуального макета для реализации.
        </div>
      </div>
      </div>
      <div class="rty">
        <div class="photo">
          <img src="images1/photo/cyril.jpg" class="img_2"alt="">
        </div>
        <div class="try">
          <div class="title_VIP">
            <div class="title">
              Kirill Pervukhin
            </div>
            <div class="VIP">
              VIP
            </div>
          </div>
          <div class="cont">
            Типичный бос-наблюдатель. Основная работа - наводить суету и задавать вопросы: "Как дела с проектом? Уже начали делать проект?"
        </div>
      </div>
      </div>
    </div>
  </body>
</html>
