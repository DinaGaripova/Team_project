<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon" href="images/icons/favicon.ico" type="image/x-icon">
	<title>NatiAir</title>
	<style>
		body{
			font-family: Montserrat, sans-serif;
			display:flex;
			justify-content:center;
			align-items:center;
			position: fixed; top: 50%; left: 50%;
			-webkit-transform: translate(-50%, -50%);
			-ms-transform: translate(-50%, -50%);
			transform: translate(-50%, -50%);
		}
		form{
			display:flex;
			flex-direction:column;
			width:400px;
		}
		input{
			margin: 10px 0;
			padding: 10px;
			border: unset;
			border-bottom: 2px solid #e3e3e3;
			outline: none;
		}
		button{
			padding: 10px;
			background: #e3e3e3;
			border:unset;
			cursor:pointer;
		}
		a{
			color: #7c9ab7;
			font-weight:bold;
			text-direction:none;
		}
		p{
			margin: 10px 0;
		} 
		.msg{
			border:2px solid #ffa908;
			border-radius: 3px;
			padding:10px;
			text-align: center;
			font-weight:bold;
		}
	</style>
</head>
<body>
		<form action="vendor/signin.php" method="post">
		<label>Логин </label>
		<input type="text" name = "login" placeholder="Введите свой логин">
		<label>Пароль</label>
		<input type="password" name="pass" placeholder="Введите свой пароль">
		<button type="submit">Войти</button>
		<p>
			У вас нет аккаунта? - <a href="register.php">Зарегистрируйтесь</a>
		</p>
			<?php 
				if($_COOKIE['message'])
				{
					echo '<p class="msg">' . $_COOKIE['message'] . '</p>';
				}
				setcookie('message', '', time()-100,"/");
			?>
		</form>
</html>