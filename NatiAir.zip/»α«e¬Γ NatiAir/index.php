<?
	if(isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	require_once 'vendor/connect.php';
	
	$query = "SELECT * FROM users WHERE token = '". $_SESSION['token']."'";
	$result = mysqli_query($link, $query);
	$profile = mysqli_fetch_assoc($result);
	
	if(!empty($_POST['fly_out']) || !empty($_POST['fly_to']) || !empty($_POST['date']) || !empty($_POST['number']))
	{
		$query= "SELECT * FROM `air` WHERE id > 0 ";
		if(!empty($_POST['fly_out'])) $query .= " AND `fly out of` = '".$_POST['fly_out']."'";
		if(!empty($_POST['fly_to'])) $query .= " AND `fly to` = '".$_POST['fly_to']."'";
		if(!empty($_POST['date'])) $query .= " AND `date` = '".$_POST['date']."'";
		if(!empty($_POST['number'])) $query .= " AND `number` = '".$_POST['number']."'";
	}
	$result = mysqli_query($link,$query);
	$counter = 0;
	
	while($res = mysqli_fetch_assoc($result))
	{
		$flights[$counter] = $res;
		$counter++;
	}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="style CSS/style.css">
	<link rel="shortcut icon" href="images/icons/favicon.ico" type="image/x-icon">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
	<meta charset="utf-8">
	<title>NatiAir</title>
</head>
<style>
.img_1
{
	height: 60px;
	margin: 10px;
}
.img_2
{
	height: 40px;
	margin: 13px;
}
.img_3
{
	height: 1200px;
}
.img_4
{
	height: 30px;
	margin: 13px;
}
</style>
<body>
	<div class="header_line">
		<div class="header_content_container">
			<div class="header_content">
				<div class="logo">
					<a href="index.php"><img src="images/full logo исходник.png" class="img_1" alt=""></a>
				</div>
				<div class="round_blocks headerButton">
					<a href="about_us.php">about us</a>
				</div>
				<div class="round_blocks headerButton">
					<a href="all_flights.php">all flights</a>
				</div>
				<div class="login">
				<?if(isset($_COOKIE[session_name()])){?>
					<a href="#"><?= $profile['name']?></a>
					<a href="vendor/logout.php">Exit</a>
				<?}
				else{?>
					<a href="auth.php">login</a>
				<?}?>
				</div>
			</div>
		</div>
	</div>
    <div class="background">
		<div class="blur">

		</div>
		<div class="content_blok">
			<div class="text">
				Travel in comfort !
			</div>
			<form method="POST" action="">
				<div class="buttons">
					<div class="i1">
						<div class="i2">
							<div class="text_1">
								Fly out of
							</div>
							<div class="text_2">
								<input class="text_2" class="text_2" type="text" name="fly_out">
							</div>
						</div>
					</div>
					<div class="i1">
						<div class="i2">
							<div class="text_1">
								fly to
							</div>
							<div class="text_2">
								<input class="text_2" type="text" name="fly_to">
							</div>
						</div>
					</div>
					<div class="i1">
						<div class="i2">
							<div class="text_1">
								date and time
							</div>
							<div class="text_2">
								<input type="date" name="date" class="text_2" value="">
							</div>
						</div>
					</div>
					<div class="i1">
						<div class="i2">
							<div class="text_1">
								number of seats
							</div>
							<div class="text_2">
								<input class="text_2" type="number" name="number" min='1' max='50'>
							</div>
						</div>
					</div>
				</div>
				<div class="boom">
					<div class="Search">
						<div class="u1">
							<div class="img_u1">
								<img src="images/icon исходник.png" class="img_2" alt="">
							</div>
							<div class="text_u1">
								<input  class="text_u1" name="btn1" type="submit" value="search">
							</div>
						</div>
						<div class="u1">
							<div class="img_u1">
								<img src="images/Close исходник.png" class="img_2" alt="">
							</div>
							<div class="text_u1">
								<button  class="text_u1" id="btn" type="submit">clear</button>
								<script>
									document.getElementById("btn").onclick = function(e) {
										document.getElementById("num").value = "";
										document.getElementById("date").value = "";
										document.getElementById("fly_to").value = "";
										document.getElementById("fly_out").value = "";
									}
								</script>
							</div>
						</div>
					</div>
				</div>
			</form>
			<?if(!empty($_POST['fly_out']) || !empty($_POST['fly_to']) || !empty($_POST['date']) || !empty($_POST['number']))
			{
				$counter = 1;
			?>
			<table class="table">
				<thead>
					<tr>
						<th>№</th>
						<th>Fly out</th>
						<th>Fly to</th>
						<th>Date</th>
						<th>Number of seats</th>
						<th>Price</th>
					</tr>
				</thead>
				<tbody>
					<?for($i = 0; $i < count($flights); $i++){?>
					<tr>
						<th><?=($i+1)?></th>
						<td><?=$flights[$i]['fly out of']?></td>
						<td><?=$flights[$i]['fly to']?></td>
						<td><?=$flights[$i]['date']?></td>
						<td><?=$flights[$i]['number']?></td>
						<td><?=$flights[$i]['cell']?></td>
					</tr>
					<?}?>
				</tbody>
			</table>
			<?}?>
			<div class="additional">
				Our company will provide comfortable transportation around the world. Fast delivery to the place and a comfortable stay.
			</div>
		</div>
    </div>
    <div class="all">
      <div class="basement">
        <div class="tr">
            © 2022–2022, Natiair — cheap air tickets.
        </div>
        <div class="tu">
					<div class="ti">
						<img src="images/vk.png" class="img_4" alt="">
					</div>
					<div class="ti">
						<img src="images/youtube.png" class="img_4" alt="">
					</div>
					<div class="ti">
						<img src="images/telegram.png" class="img_4" alt="">
					</div>
				</div>
			</div>
		</div>
	</body>
</html>